'use client';

import React, { useEffect, useState, useCallback, use } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import axiosClient from '@/lib/axios';
import { Villa, Review } from '@/types';
import { useBookingStore } from '@/store/bookingStore';
import PublicHeader from '@/components/PublicHeader';
import PublicFooter from '@/components/PublicFooter';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { getMainPhoto } from '@/lib/villaUtils';
import type { DateRange } from 'react-day-picker';
import { format, parseISO, addDays, isBefore, startOfDay } from 'date-fns';
import { Search } from 'lucide-react';
import { toast } from 'sonner';

import VillaPageSkeleton from '@/components/villa/VillaPageSkeleton';
import VillaGallerySection from '@/components/villa/VillaGallerySection';
import VillaPageHeaderSection from '@/components/villa/VillaPageHeaderSection';
import HostProfileSection from '@/components/villa/HostProfileSection';
import VillaHighlightsSection from '@/components/villa/VillaHighlightsSection';
import VillaDescriptionSection from '@/components/villa/VillaDescriptionSection';
import VillaBedroomsSection from '@/components/villa/VillaBedroomsSection';
import VillaAmenitiesSection from '@/components/villa/VillaAmenitiesSection';
import VillaAccessibilitySection from '@/components/villa/VillaAccessibilitySection';
import VillaCalendarSection from '@/components/villa/VillaCalendarSection';
import VillaReviewsSection from '@/components/villa/VillaReviewsSection';
import VillaLocationSection from '@/components/villa/VillaLocationSection';
import VillaRulesSection from '@/components/villa/VillaRulesSection';
import VillaBookingSidebar from '@/components/villa/VillaBookingSidebar';

interface PageProps {
    params: Promise<{ slug: string }>;
}

export default function VillaDetailPage({ params }: PageProps) {
    const { slug } = use(params);
    const router = useRouter();
    const searchParams = useSearchParams();
    const checkInQuery = searchParams.get('checkIn');
    const checkOutQuery = searchParams.get('checkOut');

    const [villa, setVilla] = useState<Villa | null>(null);
    const [reviews, setReviews] = useState<Review[]>([]);
    const [avgRating, setAvgRating] = useState(0);
    const [disabledDates, setDisabledDates] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);
    const [showSearchPill, setShowSearchPill] = useState(false);
    const [activeSection, setActiveSection] = useState('foto');
    const [wishlist, setWishlist] = useState<number[]>([]);
    const [isMobile, setIsMobile] = useState(false);

    const {
        setVilla: setStoreVilla, setDates: setStoreDates, setNumGuests,
        checkIn: storeCheckIn, checkOut: storeCheckOut, numGuests: storeNumGuests,
        totalNights, totalAmount
    } = useBookingStore();

    const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);

    useEffect(() => {
        const h = () => setIsMobile(window.innerWidth < 768);
        h(); window.addEventListener('resize', h);
        return () => window.removeEventListener('resize', h);
    }, []);

    useEffect(() => {
        const h = () => {
            for (const s of ['foto', 'fasilitas', 'ulasan', 'lokasi']) {
                const el = document.getElementById(`${s}-section`);
                if (el) { const r = el.getBoundingClientRect(); if (r.top <= 160 && r.bottom >= 160) { setActiveSection(s); break; } }
            }
        };
        window.addEventListener('scroll', h);
        return () => window.removeEventListener('scroll', h);
    }, []);

    useEffect(() => {
        try { const s = localStorage.getItem('pusatvilla_wishlist'); if (s) setWishlist(JSON.parse(s)); } catch (e) {}
    }, []);

    useEffect(() => {
        (async () => {
            try {
                const res = await axiosClient.get(`/villas/${slug}`);
                setVilla(res.data.villa);
                setReviews(res.data.reviews || []);
                setAvgRating(res.data.stats?.rating_avg || 0);
                setStoreVilla(res.data.villa);

                const availRes = await axiosClient.get(`/villas/${slug}/availability`);
                setDisabledDates(availRes.data.disabled_dates || []);

                if (checkInQuery && checkOutQuery) {
                    setDateRange({ from: parseISO(checkInQuery), to: parseISO(checkOutQuery) });
                    setStoreDates(checkInQuery, checkOutQuery);
                } else if (storeCheckIn && storeCheckOut) {
                    setDateRange({ from: parseISO(storeCheckIn), to: parseISO(storeCheckOut) });
                }
            } catch (err) {
                console.error(err);
                toast.error('Gagal memuat detail villa.');
            } finally { setLoading(false); }
        })();
    }, [slug]);

    const refetchAvailability = useCallback(async () => {
        try { const r = await axiosClient.get(`/villas/${slug}/availability`); setDisabledDates(r.data.disabled_dates || []); } catch (e) {}
    }, [slug]);

    useEffect(() => {
        const h = () => { if (document.visibilityState === 'visible') refetchAvailability(); };
        document.addEventListener('visibilitychange', h);
        return () => document.removeEventListener('visibilitychange', h);
    }, [refetchAvailability]);

    const handleSelectRange = (range: DateRange | undefined) => {
        setDateRange(range);
        if (range?.from && range?.to) {
            const start = startOfDay(range.from), end = startOfDay(range.to);
            let cur = start; let blocked = false;
            while (isBefore(cur, end)) {
                if (disabledDates.includes(format(cur, 'yyyy-MM-dd'))) { blocked = true; break; }
                cur = addDays(cur, 1);
            }
            if (blocked) {
                toast.error('Terdapat tanggal yang sudah dipesan di dalam rentang Anda.');
                setDateRange({ from: range.from, to: undefined });
                setStoreDates(null, null);
                return;
            }
            setStoreDates(format(range.from, 'yyyy-MM-dd'), format(range.to, 'yyyy-MM-dd'));
        } else if (range?.from) {
            setStoreDates(format(range.from, 'yyyy-MM-dd'), null);
        } else {
            setStoreDates(null, null);
        }
    };

    const handleBookingSubmit = () => {
        if (!storeCheckIn || !storeCheckOut) { scrollToSection('calendar'); toast.error('Silakan tentukan tanggal check-in dan check-out Anda.'); return; }
        router.push('/booking/confirm');
    };

    const toggleWishlist = (id: number, e: React.MouseEvent) => {
        e.preventDefault(); e.stopPropagation();
        let updated = wishlist.includes(id) ? wishlist.filter(i => i !== id) : [...wishlist, id];
        setWishlist(updated);
        localStorage.setItem('pusatvilla_wishlist', JSON.stringify(updated));
        toast.success(wishlist.includes(id) ? 'Villa dihapus dari favorit.' : 'Villa disimpan ke favorit.');
    };

    const handleShare = () => { navigator.clipboard.writeText(window.location.href); toast.success('Tautan berhasil disalin!'); };

    const scrollToSection = (id: string) => {
        const el = document.getElementById(`${id}-section`);
        if (el) { const y = el.getBoundingClientRect().top + window.scrollY - 140; window.scrollTo({ top: y, behavior: 'smooth' }); }
    };

    if (loading) return <LoadingSpinner />;
    if (!villa) return (
        <div className="text-center py-64 min-h-screen bg-slate-50 flex flex-col justify-center items-center">
            <p className="text-slate-600 text-base mb-4 font-bold">Villa tidak ditemukan atau telah dinonaktifkan.</p>
            <a href="/villas" className="text-blue-500 font-bold hover:underline">Kembali ke Katalog Villa</a>
        </div>
    );

    const photos = villa.photos?.length ? villa.photos : [getMainPhoto(null)];
    const hostName = villa.host_name || 'Host PusatVilla';
    const hostAvatar = villa.host_avatar || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(hostName) + '&background=2563eb&color=fff&size=150';
    const highlights = villa.highlights ?? [];
    const bedroomsInfo = villa.bedrooms_info ?? [];
    const accessibilityFeatures = villa.accessibility_features ?? [];

    return (
        <>
            <PublicHeader />

            <VillaPageSkeleton
                villa={{ name: villa.name, location: villa.location, slug: villa.slug }}
                isSaved={wishlist.includes(villa.id)}
                activeSection={activeSection}
                onShare={handleShare}
                onToggleWishlist={(e) => toggleWishlist(villa.id, e)}
                onScrollToSection={scrollToSection}
            >
                <VillaGallerySection photos={photos} villaName={villa.name} />

                <VillaPageHeaderSection
                    villa={villa}
                    avgRating={avgRating}
                    reviewsCount={reviews.length}
                    onScrollToReviews={() => scrollToSection('ulasan')}
                />

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 xl:gap-16 mt-2">
                    <div className="lg:col-span-2 space-y-2">
                        <HostProfileSection
                            hostName={hostName}
                            hostAvatar={hostAvatar}
                            hostYears={villa.host_years ?? 1}
                            hostIsVerified={villa.host_is_verified !== false}
                            hostAboutList={villa.host_about ?? []}
                            coHosts={villa.co_hosts ?? []}
                            hostJoinedLabel={villa.host_joined_label || 'Host terverifikasi PusatVilla.id'}
                            reviewsCount={reviews.length}
                            avgRating={avgRating}
                        />

                        {highlights.length > 0 && (
                            <VillaHighlightsSection highlights={highlights} />
                        )}

                        <VillaDescriptionSection description={villa.description} />

                        {bedroomsInfo.length > 0 && (
                            <VillaBedroomsSection bedroomsInfo={bedroomsInfo} totalBeds={villa.beds ?? null} />
                        )}

                        {villa.amenities && villa.amenities.length > 0 && (
                            <VillaAmenitiesSection amenities={villa.amenities} />
                        )}

                        {accessibilityFeatures.length > 0 && (
                            <VillaAccessibilitySection features={accessibilityFeatures} />
                        )}

                        <VillaCalendarSection dateRange={dateRange} disabledDays={disabledDates.map(d => parseISO(d))} isMobile={isMobile} onSelect={handleSelectRange} />

                        <VillaReviewsSection reviews={reviews} avgRating={avgRating} />

                        {villa.maps_url && (
                            <VillaLocationSection
                                mapsUrl={villa.maps_url}
                                location={villa.location}
                                neighborhoodDesc={villa.neighborhood_desc ?? null}
                            />
                        )}

                        <VillaRulesSection
                            rules={villa.rules}
                            safetyList={villa.safety_property ?? []}
                            cancellationPolicy={villa.cancellation_policy ?? ''}
                            maxGuests={villa.max_guests}
                        />
                    </div>

                    <VillaBookingSidebar
                        villa={villa}
                        storeCheckIn={storeCheckIn} storeCheckOut={storeCheckOut} storeNumGuests={storeNumGuests}
                        totalNights={totalNights} totalAmount={totalAmount}
                        onSetNumGuests={setNumGuests}
                        onScrollToCalendar={() => scrollToSection('calendar')}
                        onBookingSubmit={handleBookingSubmit}
                    />
                </div>
            </VillaPageSkeleton>

            <PublicFooter />
        </>
    );
}
